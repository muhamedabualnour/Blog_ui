$(document).ready(function(){
    $('.owl-carousel').owlCarousel();

    AOS.init();
});